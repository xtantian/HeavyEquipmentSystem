import "server-only";

import { createSupabaseServiceClient, createSupabaseServerClient } from "./server";
import type { Database, UserAccountStatus, UserRole, ListingStatus } from "./types";
import { MOCK_LISTINGS, MOCK_BOOKINGS, type MarketplaceListingItem } from "@/lib/marketplace/mock-listings";

export interface AdminOverviewStats {
  totalRegisteredUsers: number;
  activeUsers: number;
  currentlyActiveUsers: number;
  totalUsersUsedRental: number;
  totalActiveRentals: number;
  totalEquipmentListings: number;
  totalReportedListings: number;
  listingsByStatus: {
    available: number;
    rented: number;
    maintenance: number;
    restricted: number;
    pending_review: number;
    deleted: number;
  };
  rentalsByStatus: {
    active: number;
    paid: number;
    pending: number;
    completed: number;
    cancelled: number;
  };
  usersByStatus: {
    active: number;
    restricted: number;
    banned: number;
    deleted: number;
  };
}

export interface AdminUserItem {
  id: string;
  clerk_user_id: string;
  name: string;
  email: string;
  role: UserRole;
  status: UserAccountStatus;
  avatar_url: string | null;
  created_at: string;
  rentalCount: number;
  listingCount: number;
}

export interface AdminReportItem {
  id: string;
  listing_id: string;
  listing_title: string;
  reporter_id: string;
  reporter_email: string | null;
  reason: string;
  details: string | null;
  status: "pending" | "reviewed" | "dismissed" | "action_taken";
  created_at: string;
}

export interface AdminAuditLogItem {
  id: string;
  admin_id: string;
  admin_email: string | null;
  action: string;
  target_type: string;
  target_id: string;
  details: Record<string, unknown>;
  created_at: string;
}

/**
 * Retrieve comprehensive overview statistics from Supabase
 */
export async function getAdminOverviewStats(): Promise<AdminOverviewStats> {
  const stats: AdminOverviewStats = {
    totalRegisteredUsers: 0,
    activeUsers: 0,
    currentlyActiveUsers: 0,
    totalUsersUsedRental: 0,
    totalActiveRentals: 0,
    totalEquipmentListings: 0,
    totalReportedListings: 0,
    listingsByStatus: {
      available: 0,
      rented: 0,
      maintenance: 0,
      restricted: 0,
      pending_review: 0,
      deleted: 0,
    },
    rentalsByStatus: {
      active: 0,
      paid: 0,
      pending: 0,
      completed: 0,
      cancelled: 0,
    },
    usersByStatus: {
      active: 0,
      restricted: 0,
      banned: 0,
      deleted: 0,
    },
  };

  try {
    let supabase: ReturnType<typeof createSupabaseServiceClient>;
    try {
      supabase = createSupabaseServiceClient();
    } catch {
      supabase = (await createSupabaseServerClient()) as unknown as ReturnType<typeof createSupabaseServiceClient>;
    }

    // 1. Users / Profiles statistics
    const { data: profilesData } = await supabase
      .from("profiles")
      .select("id, clerk_user_id, status, updated_at");

    if (profilesData && profilesData.length > 0) {
      stats.totalRegisteredUsers = profilesData.length;
      const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

      for (const p of profilesData) {
        const pStatus = (p.status as UserAccountStatus) || "active";
        if (pStatus === "active") stats.activeUsers++;
        if (stats.usersByStatus[pStatus] !== undefined) {
          stats.usersByStatus[pStatus]++;
        }
        if (p.updated_at && p.updated_at >= oneDayAgo) {
          stats.currentlyActiveUsers++;
        }
      }
    } else {
      // Mock / initial baseline
      stats.totalRegisteredUsers = 12;
      stats.activeUsers = 11;
      stats.currentlyActiveUsers = 4;
      stats.usersByStatus = { active: 11, restricted: 1, banned: 0, deleted: 0 };
    }

    // 2. Listings statistics
    const { data: listingsData } = await supabase
      .from("listings")
      .select("id, status, is_reported");

    if (listingsData && listingsData.length > 0) {
      for (const item of listingsData) {
        const s = item.status as keyof typeof stats.listingsByStatus;
        if (item.status !== "deleted") {
          stats.totalEquipmentListings++;
        }
        if (stats.listingsByStatus[s] !== undefined) {
          stats.listingsByStatus[s]++;
        }
        if (item.is_reported) {
          stats.totalReportedListings++;
        }
      }
    } else {
      stats.totalEquipmentListings = MOCK_LISTINGS.length;
      stats.listingsByStatus = {
        available: MOCK_LISTINGS.filter((l) => l.status === "available").length,
        rented: 1,
        maintenance: 1,
        restricted: 1,
        pending_review: MOCK_LISTINGS.filter((l) => l.status === "pending_review").length,
        deleted: 0,
      };
      stats.totalReportedListings = 1;
    }

    // 3. Reports count from listing_reports table
    const { count: reportsCount } = await supabase
      .from("listing_reports")
      .select("*", { count: "exact", head: true })
      .eq("status", "pending");

    if (reportsCount !== null && reportsCount !== undefined && reportsCount > 0) {
      stats.totalReportedListings = Math.max(stats.totalReportedListings, reportsCount);
    }

    // 4. Rentals / Bookings statistics
    const { data: bookingsData } = await supabase
      .from("bookings")
      .select("id, renter_id, status");

    const uniqueRenters = new Set<string>();

    if (bookingsData && bookingsData.length > 0) {
      for (const b of bookingsData) {
        if (b.renter_id) uniqueRenters.add(b.renter_id);
        const st = b.status as keyof typeof stats.rentalsByStatus;
        if (["active", "paid"].includes(b.status)) {
          stats.totalActiveRentals++;
        }
        if (stats.rentalsByStatus[st] !== undefined) {
          stats.rentalsByStatus[st]++;
        }
      }
      stats.totalUsersUsedRental = uniqueRenters.size;
    } else {
      stats.totalActiveRentals = 3;
      stats.totalUsersUsedRental = 7;
      stats.rentalsByStatus = {
        active: 2,
        paid: 1,
        pending: 3,
        completed: 14,
        cancelled: 2,
      };
    }
  } catch (err) {
    console.error("[getAdminOverviewStats] Error calculating stats:", err);
  }

  return stats;
}

/**
 * Fetch all registered users with rental and listing counts
 */
export async function getAdminUsers(): Promise<AdminUserItem[]> {
  try {
    let supabase: ReturnType<typeof createSupabaseServiceClient>;
    try {
      supabase = createSupabaseServiceClient();
    } catch {
      supabase = (await createSupabaseServerClient()) as unknown as ReturnType<typeof createSupabaseServiceClient>;
    }

    const { data: profiles, error } = await supabase
      .from("profiles")
      .select("*")
      .order("created_at", { ascending: false });

    if (!error && profiles && profiles.length > 0) {
      // Gather rental & listing counts per user
      const userIds = profiles.map((p) => p.clerk_user_id);

      const [bookingsRes, listingsRes] = await Promise.all([
        supabase.from("bookings").select("renter_id").in("renter_id", userIds),
        supabase.from("listings").select("owner_id").in("owner_id", userIds),
      ]);

      const rentalCountMap: Record<string, number> = {};
      const listingCountMap: Record<string, number> = {};

      (bookingsRes.data || []).forEach((b) => {
        rentalCountMap[b.renter_id] = (rentalCountMap[b.renter_id] || 0) + 1;
      });

      (listingsRes.data || []).forEach((l) => {
        listingCountMap[l.owner_id] = (listingCountMap[l.owner_id] || 0) + 1;
      });

      return profiles.map((p) => {
        const fullName = [p.first_name, p.last_name].filter(Boolean).join(" ");
        return {
          id: p.id,
          clerk_user_id: p.clerk_user_id,
          name: fullName || p.email?.split("@")[0] || "User",
          email: p.email || "No email",
          role: (p.role as UserRole) || "customer",
          status: (p.status as UserAccountStatus) || "active",
          avatar_url: p.avatar_url,
          created_at: p.created_at,
          rentalCount: rentalCountMap[p.clerk_user_id] || 0,
          listingCount: listingCountMap[p.clerk_user_id] || 0,
        };
      });
    }
  } catch (err) {
    console.error("[getAdminUsers] Database query error:", err);
  }

  // Fallback demo users
  return [
    {
      id: "usr-1",
      clerk_user_id: "user_client_4492",
      name: "Juan Dela Cruz",
      email: "juan@rentit.ph",
      role: "admin",
      status: "active",
      avatar_url: null,
      created_at: new Date(Date.now() - 30 * 86400000).toISOString(),
      rentalCount: 5,
      listingCount: 3,
    },
    {
      id: "usr-2",
      clerk_user_id: "user_renter_8821",
      name: "Maria Santos",
      email: "maria.santos@buildcon.ph",
      role: "customer",
      status: "active",
      avatar_url: null,
      created_at: new Date(Date.now() - 20 * 86400000).toISOString(),
      rentalCount: 2,
      listingCount: 0,
    },
    {
      id: "usr-3",
      clerk_user_id: "user_owner_7733",
      name: "Ricardo Reyes",
      email: "ricardo@heavylift.ph",
      role: "customer",
      status: "restricted",
      avatar_url: null,
      created_at: new Date(Date.now() - 14 * 86400000).toISOString(),
      rentalCount: 0,
      listingCount: 4,
    },
    {
      id: "usr-4",
      clerk_user_id: "user_spammer_9911",
      name: "Suspicious Operator",
      email: "bad_actor@tempmail.com",
      role: "customer",
      status: "banned",
      avatar_url: null,
      created_at: new Date(Date.now() - 5 * 86400000).toISOString(),
      rentalCount: 0,
      listingCount: 1,
    },
  ];
}

/**
 * Fetch all listings for equipment listing management
 */
export async function getAdminAllListings(): Promise<MarketplaceListingItem[]> {
  try {
    let supabase: ReturnType<typeof createSupabaseServiceClient>;
    try {
      supabase = createSupabaseServiceClient();
    } catch {
      supabase = (await createSupabaseServerClient()) as unknown as ReturnType<typeof createSupabaseServiceClient>;
    }

    const { data, error } = await supabase
      .from("listings")
      .select(`
        *,
        category:categories(*),
        listing_images(*)
      `)
      .order("created_at", { ascending: false });

    if (!error && data && data.length > 0) {
      return data as unknown as MarketplaceListingItem[];
    }
  } catch (err) {
    console.error("[getAdminAllListings] Database query error:", err);
  }

  return MOCK_LISTINGS;
}

/**
 * Fetch reported listings and user complaints
 */
export async function getAdminReports(): Promise<AdminReportItem[]> {
  try {
    let supabase: ReturnType<typeof createSupabaseServiceClient>;
    try {
      supabase = createSupabaseServiceClient();
    } catch {
      supabase = (await createSupabaseServerClient()) as unknown as ReturnType<typeof createSupabaseServiceClient>;
    }

    const { data, error } = await supabase
      .from("listing_reports")
      .select(`
        *,
        listing:listings(title)
      `)
      .order("created_at", { ascending: false });

    if (!error && data && data.length > 0) {
      type RawReport = {
        id: string;
        listing_id: string;
        listing?: { title?: string } | null;
        reporter_id?: string | null;
        reporter_email?: string | null;
        reason: string;
        details?: string | null;
        status: string;
        created_at: string;
      };

      return (data as unknown as RawReport[]).map((r) => ({
        id: r.id,
        listing_id: r.listing_id,
        listing_title: r.listing?.title || "Listing Unit",
        reporter_id: r.reporter_id || "Anonymous",
        reporter_email: r.reporter_email || null,
        reason: r.reason,
        details: r.details || null,
        status: (r.status as AdminReportItem["status"]) || "pending",
        created_at: r.created_at,
      }));
    }
  } catch (err) {
    console.error("[getAdminReports] Database query error:", err);
  }

  // Fallback demo reports if table is newly created
  return [
    {
      id: "rep-1",
      listing_id: MOCK_LISTINGS[0]?.id || "lst-excavator-cat-320",
      listing_title: MOCK_LISTINGS[0]?.title || "CAT 320 Hydraulic Excavator",
      reporter_id: "user_renter_8821",
      reporter_email: "maria.santos@buildcon.ph",
      reason: "Inaccurate Equipment Specifications",
      details: "Rented unit has different operating weight and attachment specifications than displayed.",
      status: "pending",
      created_at: new Date(Date.now() - 2 * 86400000).toISOString(),
    },
    {
      id: "rep-2",
      listing_id: MOCK_LISTINGS[1]?.id || "lst-crane-tadano-50t",
      listing_title: MOCK_LISTINGS[1]?.title || "Tadano 50-Ton Rough Terrain Crane",
      reporter_id: "user_client_4492",
      reporter_email: "juan@rentit.ph",
      reason: "Expired Safety Certification",
      details: "The load test certification document uploaded by owner has expired.",
      status: "reviewed",
      created_at: new Date(Date.now() - 4 * 86400000).toISOString(),
    },
  ];
}

/**
 * Fetch recent audit logs of admin operations
 */
export async function getAdminAuditLogs(): Promise<AdminAuditLogItem[]> {
  try {
    let supabase: ReturnType<typeof createSupabaseServiceClient>;
    try {
      supabase = createSupabaseServiceClient();
    } catch {
      supabase = (await createSupabaseServerClient()) as unknown as ReturnType<typeof createSupabaseServiceClient>;
    }

    const { data, error } = await supabase
      .from("admin_audit_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(30);

    if (!error && data && data.length > 0) {
      return (data as unknown as Array<{
        id: string;
        admin_id: string;
        admin_email: string | null;
        action: string;
        target_type: string;
        target_id: string;
        details: Record<string, unknown>;
        created_at: string;
      }>).map((l) => ({
        id: l.id,
        admin_id: l.admin_id,
        admin_email: l.admin_email,
        action: l.action,
        target_type: l.target_type,
        target_id: l.target_id,
        details: l.details || {},
        created_at: l.created_at,
      }));
    }
  } catch (err) {
    console.error("[getAdminAuditLogs] Database query error:", err);
  }

  return [];
}
