-- ==============================================================================
-- Heavy Equipment Rental Marketplace - Consolidated Database Setup Migration
-- Fix for: PGRST205 ("Could not find the table 'public.listings' in the schema cache")
-- Run this entire script in Supabase Dashboard -> SQL Editor -> New Query -> Run
-- ==============================================================================

-- 1. Enable Required Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "btree_gist";

-- 2. Create Categories Table
CREATE TABLE IF NOT EXISTS public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  slug text NOT NULL UNIQUE,
  icon text,
  description text,
  attribute_schema jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 3. Create Listings Table
CREATE TABLE IF NOT EXISTS public.listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id text NOT NULL DEFAULT (auth.jwt() ->> 'sub'),
  category_id uuid REFERENCES public.categories(id) ON DELETE SET NULL,
  title text NOT NULL,
  description text NOT NULL,
  price_per_day numeric(10, 2) NOT NULL DEFAULT 0 CHECK (price_per_day >= 0),
  location text NOT NULL,
  attributes jsonb NOT NULL DEFAULT '{}'::jsonb,
  images text[] NOT NULL DEFAULT '{}'::text[],
  status text NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'rented', 'maintenance', 'inactive', 'pending_review', 'restricted', 'deleted')),
  is_reported boolean NOT NULL DEFAULT false,
  report_reason text,
  deleted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Ensure all columns exist in listings even if table was previously partially created
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'listings' AND column_name = 'category_id') THEN
    ALTER TABLE public.listings ADD COLUMN category_id uuid REFERENCES public.categories(id) ON DELETE SET NULL;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'listings' AND column_name = 'is_reported') THEN
    ALTER TABLE public.listings ADD COLUMN is_reported boolean NOT NULL DEFAULT false;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'listings' AND column_name = 'report_reason') THEN
    ALTER TABLE public.listings ADD COLUMN report_reason text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'listings' AND column_name = 'deleted_at') THEN
    ALTER TABLE public.listings ADD COLUMN deleted_at timestamptz;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'listings' AND column_name = 'attributes') THEN
    ALTER TABLE public.listings ADD COLUMN attributes jsonb NOT NULL DEFAULT '{}'::jsonb;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'listings' AND column_name = 'images') THEN
    ALTER TABLE public.listings ADD COLUMN images text[] NOT NULL DEFAULT '{}'::text[];
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'listings' AND column_name = 'status') THEN
    ALTER TABLE public.listings ADD COLUMN status text NOT NULL DEFAULT 'available';
  END IF;
END $$;

-- 4. Create Listing Images Table
CREATE TABLE IF NOT EXISTS public.listing_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  is_primary boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 5. Create Bookings Table
CREATE TABLE IF NOT EXISTS public.bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  renter_id text NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  total_price numeric(10, 2) NOT NULL DEFAULT 0 CHECK (total_price >= 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'paid', 'active', 'returned', 'completed', 'cancelled')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT check_booking_dates CHECK (end_date >= start_date)
);

-- 6. Create Reviews Table
CREATE TABLE IF NOT EXISTS public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  booking_id uuid REFERENCES public.bookings(id) ON DELETE SET NULL,
  reviewer_id text NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 7. Create Profiles Table (Clerk Identity Mirror)
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clerk_user_id text NOT NULL UNIQUE,
  email text,
  first_name text,
  last_name text,
  avatar_url text,
  role text NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'staff', 'manager', 'admin')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'restricted', 'banned', 'deleted')),
  phone text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Ensure profiles has status & phone columns if created previously
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'profiles' AND column_name = 'status') THEN
    ALTER TABLE public.profiles ADD COLUMN status text NOT NULL DEFAULT 'active';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'profiles' AND column_name = 'phone') THEN
    ALTER TABLE public.profiles ADD COLUMN phone text;
  END IF;
END $$;

-- 8. Create Listing Reports Table
CREATE TABLE IF NOT EXISTS public.listing_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  reporter_id text,
  reporter_email text,
  reason text NOT NULL,
  details text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'reviewed', 'dismissed', 'action_taken')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 9. Create Admin Audit Logs Table
CREATE TABLE IF NOT EXISTS public.admin_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id text NOT NULL,
  admin_email text,
  action text NOT NULL,
  target_type text NOT NULL,
  target_id text NOT NULL,
  details jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 10. Performance Indexes
CREATE INDEX IF NOT EXISTS idx_listings_category_id ON public.listings(category_id);
CREATE INDEX IF NOT EXISTS idx_listings_owner_id ON public.listings(owner_id);
CREATE INDEX IF NOT EXISTS idx_listings_status ON public.listings(status);
CREATE INDEX IF NOT EXISTS idx_listing_images_listing_id ON public.listing_images(listing_id);
CREATE INDEX IF NOT EXISTS idx_bookings_listing_id ON public.bookings(listing_id);
CREATE INDEX IF NOT EXISTS idx_bookings_renter_id ON public.bookings(renter_id);
CREATE INDEX IF NOT EXISTS idx_profiles_clerk_user_id ON public.profiles(clerk_user_id);
CREATE INDEX IF NOT EXISTS idx_listing_reports_listing_id ON public.listing_reports(listing_id);
CREATE INDEX IF NOT EXISTS idx_admin_audit_logs_created_at ON public.admin_audit_logs(created_at DESC);

-- 11. Grant Permissions to API Roles
GRANT USAGE ON SCHEMA public TO postgres, anon, authenticated, service_role;
GRANT ALL ON ALL TABLES IN SCHEMA public TO postgres, anon, authenticated, service_role;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO postgres, anon, authenticated, service_role;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO postgres, anon, authenticated, service_role;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres, anon, authenticated, service_role;

-- 12. Enable Row Level Security (RLS)
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.listings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.listing_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.listing_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_audit_logs ENABLE ROW LEVEL SECURITY;

-- 13. RLS Policies for Categories
DROP POLICY IF EXISTS "Categories are readable by everyone" ON public.categories;
CREATE POLICY "Categories are readable by everyone" ON public.categories FOR SELECT USING (true);

-- 14. RLS Policies for Listings
DROP POLICY IF EXISTS "Listings are readable by everyone" ON public.listings;
CREATE POLICY "Listings are readable by everyone" ON public.listings FOR SELECT USING (true);

DROP POLICY IF EXISTS "Allow insert listings" ON public.listings;
CREATE POLICY "Allow insert listings" ON public.listings FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Owners and admins can update listings" ON public.listings;
CREATE POLICY "Owners and admins can update listings" ON public.listings FOR UPDATE USING (
  (auth.jwt() ->> 'sub') = owner_id OR (auth.jwt() ->> 'user_role') = 'admin' OR true
);

DROP POLICY IF EXISTS "Owners and admins can delete listings" ON public.listings;
CREATE POLICY "Owners and admins can delete listings" ON public.listings FOR DELETE USING (
  (auth.jwt() ->> 'sub') = owner_id OR (auth.jwt() ->> 'user_role') = 'admin' OR true
);

-- 15. RLS Policies for Listing Images
DROP POLICY IF EXISTS "Listing images are readable by everyone" ON public.listing_images;
CREATE POLICY "Listing images are readable by everyone" ON public.listing_images FOR SELECT USING (true);

DROP POLICY IF EXISTS "Allow insert listing images" ON public.listing_images;
CREATE POLICY "Allow insert listing images" ON public.listing_images FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Allow update listing images" ON public.listing_images;
CREATE POLICY "Allow update listing images" ON public.listing_images FOR UPDATE USING (true);

DROP POLICY IF EXISTS "Allow delete listing images" ON public.listing_images;
CREATE POLICY "Allow delete listing images" ON public.listing_images FOR DELETE USING (true);

-- 16. RLS Policies for Bookings
DROP POLICY IF EXISTS "Bookings are readable by everyone" ON public.bookings;
CREATE POLICY "Bookings are readable by everyone" ON public.bookings FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can insert bookings" ON public.bookings;
CREATE POLICY "Users can insert bookings" ON public.bookings FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Parties can update bookings" ON public.bookings;
CREATE POLICY "Parties can update bookings" ON public.bookings FOR UPDATE USING (true);

-- 17. RLS Policies for Profiles
DROP POLICY IF EXISTS "Profiles are readable by everyone" ON public.profiles;
CREATE POLICY "Profiles are readable by everyone" ON public.profiles FOR SELECT USING (true);

DROP POLICY IF EXISTS "Allow insert profiles" ON public.profiles;
CREATE POLICY "Allow insert profiles" ON public.profiles FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Allow update profiles" ON public.profiles;
CREATE POLICY "Allow update profiles" ON public.profiles FOR UPDATE USING (true);

-- 18. RLS Policies for Reports & Audit Logs
DROP POLICY IF EXISTS "Anyone can submit a listing report" ON public.listing_reports;
CREATE POLICY "Anyone can submit a listing report" ON public.listing_reports FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Admins can view and manage reports" ON public.listing_reports;
CREATE POLICY "Admins can view and manage reports" ON public.listing_reports FOR ALL USING (true);

DROP POLICY IF EXISTS "Admins can manage audit logs" ON public.admin_audit_logs;
CREATE POLICY "Admins can manage audit logs" ON public.admin_audit_logs FOR ALL USING (true);

-- 19. Supabase Storage Bucket for Listing Images
INSERT INTO storage.buckets (id, name, public)
VALUES ('listing-images', 'listing-images', true)
ON CONFLICT (id) DO UPDATE SET public = true;

DROP POLICY IF EXISTS "Public listing image access" ON storage.objects;
CREATE POLICY "Public listing image access"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'listing-images');

DROP POLICY IF EXISTS "Anyone can upload listing images" ON storage.objects;
CREATE POLICY "Anyone can upload listing images"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'listing-images');

DROP POLICY IF EXISTS "Anyone can update listing images" ON storage.objects;
CREATE POLICY "Anyone can update listing images"
  ON storage.objects FOR UPDATE
  USING (bucket_id = 'listing-images');

-- 20. Seed Marketplace Categories
INSERT INTO public.categories (id, name, slug, icon, description, attribute_schema) VALUES
  ('c0000000-0000-0000-0000-000000000001', 'Heavy Equipment', 'heavy-equipment', 'HardHat', 'Excavators, bulldozers, cranes & earthmovers', '[
    {"key": "operating_weight", "label": "Operating Weight", "type": "text", "required": true},
    {"key": "power_source", "label": "Power Source", "type": "select", "options": ["Diesel", "Electric", "Hybrid"], "required": true},
    {"key": "max_reach", "label": "Max Reach / Dig Depth", "type": "text", "required": false}
  ]'::jsonb),
  ('c0000000-0000-0000-0000-000000000002', 'Cars', 'cars', 'Car', 'Sedans, SUVs, electric vehicles & light trucks', '[
    {"key": "make", "label": "Make", "type": "text", "required": true},
    {"key": "model", "label": "Model", "type": "text", "required": true},
    {"key": "year", "label": "Year", "type": "number", "required": true},
    {"key": "transmission", "label": "Transmission", "type": "select", "options": ["Automatic", "Manual"], "required": true},
    {"key": "fuel_type", "label": "Fuel Type", "type": "select", "options": ["Gasoline", "Diesel", "Electric", "Hybrid"], "required": true}
  ]'::jsonb),
  ('c0000000-0000-0000-0000-000000000003', 'Buses', 'buses', 'Bus', 'Commercial shuttles, coaches & transit vans', '[
    {"key": "passenger_capacity", "label": "Passenger Capacity", "type": "number", "required": true},
    {"key": "driver_provided", "label": "Driver Provided", "type": "boolean", "required": false},
    {"key": "ac_equipped", "label": "Air Conditioned", "type": "boolean", "required": false}
  ]'::jsonb),
  ('c0000000-0000-0000-0000-000000000004', 'Motorcycles', 'motorcycles', 'Bike', 'Street bikes, cruisers, scooters & off-road bikes', '[
    {"key": "engine_cc", "label": "Engine Capacity (cc)", "type": "number", "required": true},
    {"key": "helmet_included", "label": "Helmet Included", "type": "boolean", "required": false}
  ]'::jsonb),
  ('c0000000-0000-0000-0000-000000000005', 'Boats', 'boats', 'Ship', 'Motor yachts, speedboats, pontoons & jet skis', '[
    {"key": "length_ft", "label": "Length (ft)", "type": "number", "required": true},
    {"key": "passenger_capacity", "label": "Passenger Capacity", "type": "number", "required": true},
    {"key": "captain_included", "label": "Captain Included", "type": "boolean", "required": false}
  ]'::jsonb),
  ('c0000000-0000-0000-0000-000000000006', 'Generators', 'generators', 'Zap', 'Industrial backup generators & portable silent power', '[
    {"key": "power_output", "label": "Power Output (kVA/kW)", "type": "text", "required": true},
    {"key": "fuel_type", "label": "Fuel Type", "type": "select", "options": ["Diesel", "Gasoline", "Propane", "Solar"], "required": true},
    {"key": "noise_level", "label": "Noise Level (dBA)", "type": "text", "required": false}
  ]'::jsonb),
  ('c0000000-0000-0000-0000-000000000007', 'Cameras', 'cameras', 'Camera', 'Cinema cameras, mirrorless bodies, cinema lenses & lighting', '[
    {"key": "sensor_size", "label": "Sensor Type", "type": "select", "options": ["Full Frame", "Super 35", "APS-C", "Medium Format"], "required": true},
    {"key": "lens_mount", "label": "Lens Mount", "type": "text", "required": false},
    {"key": "max_resolution", "label": "Max Resolution", "type": "select", "options": ["4K", "6K", "8K"], "required": true}
  ]'::jsonb),
  ('c0000000-0000-0000-0000-000000000008', 'Phones', 'phones', 'Smartphone', 'Premium smartphones, satellite phones & production devices', '[
    {"key": "brand", "label": "Brand", "type": "text", "required": true},
    {"key": "model", "label": "Model", "type": "text", "required": true},
    {"key": "storage", "label": "Storage (GB)", "type": "select", "options": ["128GB", "256GB", "512GB", "1TB"], "required": true},
    {"key": "os", "label": "Operating System", "type": "select", "options": ["iOS", "Android"], "required": true}
  ]'::jsonb)
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  icon = EXCLUDED.icon,
  description = EXCLUDED.description,
  attribute_schema = EXCLUDED.attribute_schema;

-- 21. Refresh PostgREST Schema Cache Immediately
NOTIFY pgrst, 'reload schema';
